import SwiftUI

struct TrapeziumView: View {
    @State private var base1: Double = 120
    @State private var base2: Double = 80
    @State private var height: Double = 60
    @State private var animateCards = false
    @State private var flipped = [false, false, false]
    
    var area: Double {
        0.5 * (base1 + base2) * height
    }
    
    var body: some View {
        ScrollView {
            VStack(spacing: 20) {
                ZStack {
                    Path { path in
                        let topLeft = CGPoint(x: 150, y: 150)
                        let topRight = CGPoint(x: 150 + base1, y: 150)
                        let bottomRight = CGPoint(x: 150 + base2, y: 150 + height)
                        let bottomLeft = CGPoint(x: 150, y: 150 + height)
                        path.move(to: topLeft)
                        path.addLines([topRight, bottomRight, bottomLeft, topLeft])
                    }
                    .stroke(Color.purple, lineWidth: 3)
                    
                    Text("Base1: \(Int(base1)), Base2: \(Int(base2)), Height: \(Int(height))")
                        .font(.caption)
                        .foregroundColor(.gray)
                        .offset(y: 100)
                }
                .frame(height: 300)
                
                Divider()
                
                Text("Area = ½ × (base₁ + base₂) × height = \(String(format: "%.2f", area)) sq units")
                    .font(.headline)
                    .multilineTextAlignment(.center)
                    .padding()
                
                Group {
                    HStack {
                        Text("Base 1:")
                        TextField("Base 1", value: $base1, format: .number)
                            .textFieldStyle(.roundedBorder)
                            .keyboardType(.decimalPad)
                        Text("Base 2:")
                        TextField("Base 2", value: $base2, format: .number)
                            .textFieldStyle(.roundedBorder)
                            .keyboardType(.decimalPad)
                    }
                    
                    HStack {
                        Text("Height:")
                        TextField("Height", value: $height, format: .number)
                            .textFieldStyle(.roundedBorder)
                            .keyboardType(.decimalPad)
                    }
                }
                .padding(.horizontal)
                
                Divider()
                
                VStack(spacing: 20) {
                    ForEach(0..<3) { index in
                        let title = ["Area", "Average Base", "Height"][index]
                        let value: String = {
                            switch index {
                            case 0: return "\(String(format: "%.2f", area)) sq units"
                            case 1: return "\(String(format: "%.2f", (base1 + base2) / 2)) units"
                            default: return "\(String(format: "%.2f", height)) units"
                            }
                        }()
                        let formula = [
                            "Area = ½ × (base₁ + base₂) × height",
                            "Avg Base = (base₁ + base₂) / 2",
                            "Height = vertical distance between bases"
                        ][index]
                        
                        ZStack {
                            RoundedRectangle(cornerRadius: 20)
                                .fill(Color.purple)
                                .frame(height: 100)
                                .shadow(radius: 10)
                            
                            if flipped[index] {
                                Text(formula)
                                    .scaleEffect(x: -1, y: 1)
                                    .font(.headline)
                                    .foregroundColor(.white)
                                    .padding()
                            } else {
                                VStack {
                                    Text(title)
                                        .font(.title)
                                        .foregroundColor(.white)
                                        .bold()
                                    Text(value)
                                        .font(.subheadline)
                                        .foregroundColor(.white.opacity(0.8))
                                }
                                .padding()
                            }
                        }
                        .padding(.horizontal)
                        .rotation3DEffect(.degrees(flipped[index] ? 180 : 0), axis: (x: 0, y: 1, z: 0))
                        .onTapGesture {
                            withAnimation { flipped[index].toggle() }
                        }
                        .offset(y: animateCards ? 0 : 100)
                        .opacity(animateCards ? 1 : 0)
                        .animation(.easeOut.delay(Double(index) * 0.2), value: animateCards)
                    }
                }
                .onAppear { animateCards = true }
                
                Divider()
                
                ZStack {
                    Image("yourBackgroundImage")
                        .resizable()
                        .scaledToFill()
                        .ignoresSafeArea()
                    
                    VStack {
                        VStack(alignment: .leading, spacing: 10) {
                            Text("Interesting Facts")
                                .font(.title)
                                .fontWeight(.bold)
                                .frame(maxWidth: .infinity)
                            Text("A trapezium (or trapezoid) has one pair of opposite sides that are parallel. It's a common shape in bridges and architecture.")
                        }
                        .padding()
                        .background(.ultraThinMaterial)
                        .cornerRadius(20)
                        .shadow(radius: 10)
                        .padding()
                    }
                }
                
                Spacer()
            }
            .padding()
        }
    }
}
