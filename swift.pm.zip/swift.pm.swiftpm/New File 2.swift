import SwiftUI

struct SquareView: View {
    @State private var h: Double = 0
    @State private var k: Double = 0
    @State private var side: Double = 50
    @State private var flipped = [false, false, false]
    @State private var animateCards = false
    
    var body: some View {
        ScrollView {
            VStack(spacing: 20) {
                
                // Square display
                ZStack {
                    Rectangle()
                        .stroke(Color.green, lineWidth: 3)
                        .frame(width: side, height: side)
                        .position(x: 150 + CGFloat(h), y: 150 - CGFloat(k))
                    
                    Text("Center (\(String(format: "%.1f", h)), \(String(format: "%.1f", k)))")
                        .font(.caption)
                        .foregroundColor(.gray)
                        .offset(y: 100)
                }
                .frame(height: 300)
                
                Divider()
                
                // Equation
                
                // Input Fields
                Group {
                    HStack {
                        Text("H:")
                        TextField("H", value: $h, format: .number)
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                            .keyboardType(.decimalPad)
                        Text("K:")
                        TextField("K", value: $k, format: .number)
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                            .keyboardType(.decimalPad)
                    }
                    
                    HStack {
                        Text("Side:")
                        TextField("Side", value: $side, format: .number)
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                            .keyboardType(.decimalPad)
                    }
                }
                .padding(.horizontal)
                
                Divider()
                
                // Flip Cards
                VStack(spacing: 20) {
                    ForEach(0..<3, id: \.self) { index in
                        let title = ["Perimeter", "Area", "Diagonal"][index]
                        let value: String = {
                            switch index {
                            case 0: return "\(String(format: "%.2f", 4 * side)) units"
                            case 1: return "\(String(format: "%.2f", side * side)) sq units"
                            default: return "\(String(format: "%.2f", side * sqrt(2))) units"
                            }
                        }()
                        let formula = [
                            "Perimeter = 4 × side",
                            "Area = side²",
                            "Diagonal = side × √2"
                        ][index]
                        
                        ZStack {
                            RoundedRectangle(cornerRadius: 20)
                                .fill(Color.green)
                                .frame(height: 100)
                                .shadow(radius: 10)
                            
                            if flipped[index] {
                                Text(formula)
                                    .scaleEffect(x: -1, y: 1)
                                    .font(.headline)
                                    .foregroundColor(.white)
                                    .padding()
                            } else {
                                VStack {
                                    Text(title)
                                        .font(.title)
                                        .foregroundColor(.white)
                                        .bold()
                                    Text(value)
                                        .font(.subheadline)
                                        .foregroundColor(.white.opacity(0.8))
                                }
                                .padding()
                            }
                        }
                        .padding(.horizontal)
                        .rotation3DEffect(
                            .degrees(flipped[index] ? 180 : 0),
                            axis: (x: 0, y: 1, z: 0)
                        )
                        .onTapGesture {
                            withAnimation(.easeInOut) {
                                flipped[index].toggle()
                            }
                        }
                        .offset(y: animateCards ? 0 : 100)
                        .opacity(animateCards ? 1 : 0)
                        .animation(.easeOut.delay(Double(index) * 0.2), value: animateCards)
                    }
                }
                .onAppear {
                    animateCards = true
                }
                
                Spacer()
            }
            
            
            Divider()
            
            ZStack {
                // Background image or color
                Image("yourBackgroundImage") // Optional, for more glass effect
                    .resizable()
                    .scaledToFill()
                    .ignoresSafeArea()
                
                VStack {
                    
                    
                    // Glass Card
                    VStack(alignment: .leading, spacing: 10) {
                        Text("Interesting Facts")
                            .font(.title)
                            .frame(maxWidth: /*@START_MENU_TOKEN@*/.infinity/*@END_MENU_TOKEN@*/)
                            .fontWeight(.bold)
                        Text("A square is 4-sided shape with all sides equal and all angles at 90 degrees.")
                            .font(.body)
                    }
                    .padding()
                    .background(.ultraThinMaterial) // Frosted glass effect
                    .cornerRadius(20)
                    .shadow(radius: 10)
                    .padding()
                    
                    Spacer()
                }
            }
        }
    }
}
