import SwiftUI

struct ContentView: View {
    @State private var searchText = ""
    
    let allShapes = ["Circle", "Square", "Rectangle", "Parabola", "Ellipse","Triangle","Trapezium"]
    
    var filteredShapes: [String] {
        if searchText.isEmpty {
            return allShapes
        } else {
            return allShapes.filter { $0.localizedCaseInsensitiveContains(searchText) }
        }
    }
    
    var body: some View {
        NavigationView {
            VStack(alignment: .leading, spacing: 16) {
                Text("Shapes")
                    .font(.largeTitle)
                    .bold()
                
                // Search Bar
                HStack {
                    Image(systemName: "magnifyingglass")
                        .foregroundColor(.gray)
                    TextField("Search", text: $searchText)
                }
                
                .cornerRadius(50)
                .padding(10)
                .background(Color(.systemGray6))
                .padding()
                
                // Shape List with Navigation
                List(filteredShapes, id: \.self) { shape in
                    NavigationLink(destination: destinationView(for: shape)) {
                        Text(shape)
                            .padding(.vertical, 8)
                    }
                }
                .listStyle(PlainListStyle())
                
                Spacer()
            }
            .padding()
            
        }
    }
    
    // MARK: - Navigation destination
    @ViewBuilder
    func destinationView(for shape: String) -> some View {
        switch shape {
        case "Circle":
            CircleView()
        case "Square":
            SquareView()
        case "Rectangle":
            RectangleView()
        case "Ellipse":
            EllipseView()
        case "Parabola":
            ParabolaView()
        case "Triangle":
            TriangleView()
        case "Trapezium":
            TrapeziumView()
        
        default:
            Text("Unknown Shape")
        }
    }
}

@main
struct ShapesMenuApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
