import SwiftUI

struct EllipseView: View {
    @State private var h: Double = 0
    @State private var k: Double = 0
    @State private var a: Double = 80   // Horizontal radius
    @State private var b: Double = 50   // Vertical radius
    @State private var animateCards = false
    @State private var flipped = [false, false, false] // For equation, foci, eccentricity
    
    var body: some View {
        ScrollView {
            VStack(spacing: 20) {
                // Ellipse display
                ZStack {
                    Ellipse()
                        .stroke(Color.teal, lineWidth: 3)
                        .frame(width: a * 2, height: b * 2)
                        .position(x: 150 + CGFloat(h), y: 150 - CGFloat(k))
                    
                    Text("Center (\(String(format: "%.1f", h)), \(String(format: "%.1f", k)))")
                        .font(.caption)
                        .foregroundColor(.gray)
                        .offset(y: 100)
                }
                .frame(height: 300)
                
                Divider()
                
                // Equation
                Text("Equation: (x - \(String(format: "%.1f", h)))² / \(String(format: "%.1f", a * a)) + (y - \(String(format: "%.1f", k)))² / \(String(format: "%.1f", b * b)) = 1")
                    .font(.headline)
                    .multilineTextAlignment(.center)
                    .padding()
                
                // Input Fields
                Group {
                    HStack {
                        Text("H:")
                        TextField("H", value: $h, format: .number)
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                            .keyboardType(.decimalPad)
                        Text("K:")
                        TextField("K", value: $k, format: .number)
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                            .keyboardType(.decimalPad)
                    }
                    
                    HStack {
                        Text("a (horiz):")
                        TextField("a", value: $a, format: .number)
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                            .keyboardType(.decimalPad)
                        Text("b (vert):")
                        TextField("b", value: $b, format: .number)
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                            .keyboardType(.decimalPad)
                    }
                }
                .padding(.horizontal)
                
                Divider()
                
                // Flip Cards
                VStack(spacing: 20) {
                    ForEach(0..<3) { index in
                        let title = ["Foci Distance", "Eccentricity", "Area"][index]
                        let value: String = {
                            switch index {
                            case 0:
                                let c = sqrt(abs(a * a - b * b))
                                return "±\(String(format: "%.2f", c)) units"
                            case 1:
                                let e = sqrt(abs(a * a - b * b)) / max(a, b)
                                return "\(String(format: "%.3f", e))"
                            default:
                                return "\(String(format: "%.2f", .pi * a * b)) square units"
                            }
                        }()
                        let formula = [
                            "c = √|a² - b²| (distance from center to foci)",
                            "e = c / a or c / b (depending on orientation)",
                            "Area = π × a × b"
                        ][index]
                        
                        ZStack {
                            RoundedRectangle(cornerRadius: 20)
                                .fill(Color.teal)
                                .frame(height: 100)
                                .shadow(radius: 10)
                            
                            if flipped[index] {
                                Text(formula)
                                    .scaleEffect(x: -1, y: 1)
                                    .font(.headline)
                                    .foregroundColor(.white)
                                    .padding()
                            } else {
                                VStack {
                                    Text(title)
                                        .font(.title)
                                        .foregroundColor(.white)
                                        .bold()
                                    Text(value)
                                        .font(.subheadline)
                                        .foregroundColor(.white.opacity(0.8))
                                }
                                .padding()
                            }
                        }
                        .padding(.horizontal)
                        .rotation3DEffect(
                            .degrees(flipped[index] ? 180 : 0),
                            axis: (x: 0, y: 1, z: 0)
                        )
                        .onTapGesture {
                            withAnimation(.easeInOut) {
                                flipped[index].toggle()
                            }
                        }
                        .offset(y: animateCards ? 0 : 100)
                        .opacity(animateCards ? 1 : 0)
                        .animation(.easeOut.delay(Double(index) * 0.2), value: animateCards)
                    }
                }
                .onAppear {
                    animateCards = true
                }
                
                Divider()
                
                // Interesting Facts (glass card)
                ZStack {
                    Image("yourBackgroundImage") // Optional background
                        .resizable()
                        .scaledToFill()
                        .ignoresSafeArea()
                    
                    VStack {
                        VStack(alignment: .leading, spacing: 10) {
                            Text("Interesting Facts")
                                .font(.title)
                                .frame(maxWidth: .infinity)
                                .fontWeight(.bold)
                            Text("In an ellipse, the total distance from any point on the curve to the two foci is constant.")
                                .font(.body)
                        }
                        .padding()
                        .background(.ultraThinMaterial)
                        .cornerRadius(20)
                        .shadow(radius: 10)
                        .padding()
                        
                        Spacer()
                    }
                }
                
                Spacer()
            }
            .padding()
        }
    }
}
