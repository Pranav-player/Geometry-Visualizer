import SwiftUI


struct RectangleView: View {
    @State private var h: Double = 0
    @State private var k: Double = 0
    @State private var width: Double = 100
    @State private var height: Double = 60
    @State private var flipped = [false, false, false]
    @State private var animateCards = false
    
    var body: some View {
        ScrollView {
            VStack(spacing: 20) {
                
                // Rectangle Display
                ZStack {
                    Rectangle()
                        .stroke(Color.orange, lineWidth: 3)
                        .frame(width: width, height: height)
                        .position(x: 150 + CGFloat(h), y: 150 - CGFloat(k))
                    
                    Text("Center (\(String(format: "%.1f", h)), \(String(format: "%.1f", k)))")
                        .font(.caption)
                        .foregroundColor(.gray)
                        .offset(y: 100)
                }
                .frame(height: 300)
                
                Divider()
                
                // Input Fields
                Group {
                    HStack {
                        Text("H:")
                        TextField("H", value: $h, format: .number)
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                            .keyboardType(.decimalPad)
                        Text("K:")
                        TextField("K", value: $k, format: .number)
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                            .keyboardType(.decimalPad)
                    }
                    
                    HStack {
                        Text("Width:")
                        TextField("Width", value: $width, format: .number)
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                            .keyboardType(.decimalPad)
                        Text("Height:")
                        TextField("Height", value: $height, format: .number)
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                            .keyboardType(.decimalPad)
                    }
                }
                .padding(.horizontal)
                
                Divider()
                
                // Flip Cards
                VStack(spacing: 20) {
                    ForEach(0..<3, id: \.self) { index in
                        let title = ["Perimeter", "Area", "Diagonal"][index]
                        let value: String = {
                            switch index {
                            case 0: return "\(String(format: "%.2f", 2 * (width + height))) units"
                            case 1: return "\(String(format: "%.2f", width * height)) sq units"
                            default: return "\(String(format: "%.2f", sqrt(width * width + height * height))) units"
                            }
                        }()
                        let formula = [
                            "Perimeter = 2 × (width + height)",
                            "Area = width × height",
                            "Diagonal = √(width² + height²)"
                        ][index]
                        
                        ZStack {
                            RoundedRectangle(cornerRadius: 20)
                                .fill(Color.orange)
                                .frame(height: 100)
                                .shadow(radius: 10)
                            
                            if flipped[index] {
                                Text(formula)
                                    .scaleEffect(x: -1, y: 1)
                                    .font(.headline)
                                    .foregroundColor(.white)
                                    .padding()
                            } else {
                                VStack {
                                    Text(title)
                                        .font(.title)
                                        .foregroundColor(.white)
                                        .bold()
                                    Text(value)
                                        .font(.subheadline)
                                        .foregroundColor(.white.opacity(0.8))
                                }
                                .padding()
                            }
                        }
                        .padding(.horizontal)
                        .rotation3DEffect(
                            .degrees(flipped[index] ? 180 : 0),
                            axis: (x: 0, y: 1, z: 0)
                        )
                        .onTapGesture {
                            withAnimation(.easeInOut) {
                                flipped[index].toggle()
                            }
                        }
                        .offset(y: animateCards ? 0 : 100)
                        .opacity(animateCards ? 1 : 0)
                        .animation(.easeOut.delay(Double(index) * 0.2), value: animateCards)
                    }
                }
                .onAppear {
                    animateCards = true
                }
                
                Spacer()
                
                Divider()
                
                // Glass Card Section
                ZStack {
                    Image("yourBackgroundImage") // Optional background
                        .resizable()
                        .scaledToFill()
                        .ignoresSafeArea()
                    
                    VStack {
                        VStack(alignment: .leading, spacing: 10) {
                            Text("Interesting Facts")
                                .font(.title)
                                .frame(maxWidth: .infinity)
                                .fontWeight(.bold)
                            Text("A rectangle is a 4-sided shape with opposite sides equal and all angles at 90 degrees.")
                                .font(.body)
                        }
                        .padding()
                        .background(.ultraThinMaterial)
                        .cornerRadius(20)
                        .shadow(radius: 10)
                        .padding()
                        
                        Spacer()
                    }
                }
            }
        }
    }
}
