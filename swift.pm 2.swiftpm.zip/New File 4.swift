import SwiftUI

struct ParabolaView: View {
    @State private var h: Double = 0
    @State private var k: Double = 0
    @State private var a: Double = 1
    @State private var animateCards = false
    @State private var flipped = [false, false, false] // For Focus, Directrix, Direction
    
    var body: some View {
        ScrollView {
            VStack(spacing: 20) {
                
                // Parabola Drawing
                ZStack {
                    Path { path in
                        let scale: CGFloat = 10
                        let centerX = 150.0 + CGFloat(h)
                        let centerY = 150.0 - CGFloat(k)
                        
                        var first = true
                        for x in stride(from: -5.0, through: 5.0, by: 0.1) {
                            let y = a * x * x
                            let point = CGPoint(
                                x: centerX + CGFloat(x) * scale,
                                y: centerY - CGFloat(y) * scale
                            )
                            if first {
                                path.move(to: point)
                                first = false
                            } else {
                                path.addLine(to: point)
                            }
                        }
                    }
                    .stroke(Color.purple, lineWidth: 2)
                    
                    Text("Vertex (\(String(format: "%.1f", h)), \(String(format: "%.1f", k)))")
                        .font(.caption)
                        .foregroundColor(.gray)
                        .offset(y: 100)
                }
                .frame(height: 300)
                
                Divider()
                
                // Equation
                Text("Equation: y = \(String(format: "%.1f", a))(x - \(String(format: "%.1f", h)))² + \(String(format: "%.1f", k))")
                    .font(.headline)
                    .multilineTextAlignment(.center)
                    .padding()
                
                // Input Fields
                Group {
                    HStack {
                        Text("H:")
                        TextField("H", value: $h, format: .number)
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                            .keyboardType(.decimalPad)
                        
                        Text("K:")
                        TextField("K", value: $k, format: .number)
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                            .keyboardType(.decimalPad)
                    }
                    
                    HStack {
                        Text("a:")
                        TextField("a", value: $a, format: .number)
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                            .keyboardType(.decimalPad)
                    }
                }
                .padding(.horizontal)
                
                Divider()
                
                // Flip Cards
                VStack(spacing: 20) {
                    ForEach(0..<3, id: \.self) { index in
                        let title = ["Focus", "Directrix", "Direction"][index]
                        let value: String = {
                            switch index {
                            case 0:
                                let fy = k + 1 / (4 * a)
                                return "(\(String(format: "%.2f", h)), \(String(format: "%.2f", fy)))"
                            case 1:
                                let dy = k - 1 / (4 * a)
                                return "y = \(String(format: "%.2f", dy))"
                            default:
                                return a > 0 ? "Opens Upward" : "Opens Downward"
                            }
                        }()
                        let formula = [
                            "Focus: (h, k + 1 / 4a)",
                            "Directrix: y = k - 1 / 4a",
                            "a > 0 ⇒ Upward, a < 0 ⇒ Downward"
                        ][index]
                        
                        ZStack {
                            RoundedRectangle(cornerRadius: 20)
                                .fill(Color.purple)
                                .frame(height: 100)
                                .shadow(radius: 10)
                            
                            if flipped[index] {
                                Text(formula)
                                    .scaleEffect(x: -1, y: 1)
                                    .font(.headline)
                                    .foregroundColor(.white)
                                    .padding()
                            } else {
                                VStack {
                                    Text(title)
                                        .font(.title)
                                        .foregroundColor(.white)
                                        .bold()
                                    Text(value)
                                        .font(.subheadline)
                                        .foregroundColor(.white.opacity(0.8))
                                }
                                .padding()
                            }
                        }
                        .padding(.horizontal)
                        .rotation3DEffect(
                            .degrees(flipped[index] ? 180 : 0),
                            axis: (x: 0, y: 1, z: 0)
                        )
                        .onTapGesture {
                            withAnimation(.easeInOut) {
                                flipped[index].toggle()
                            }
                        }
                        .offset(y: animateCards ? 0 : 100)
                        .opacity(animateCards ? 1 : 0)
                        .animation(.easeOut.delay(Double(index) * 0.2), value: animateCards)
                    }
                }
                .onAppear {
                    animateCards = true
                }
                
                Divider()
                
                // Interesting Facts Section
                ZStack {
                    Image("yourBackgroundImage") // Optional
                        .resizable()
                        .scaledToFill()
                        .ignoresSafeArea()
                    
                    VStack {
                        VStack(alignment: .leading, spacing: 10) {
                            Text("Interesting Facts")
                                .font(.title)
                                .frame(maxWidth: .infinity)
                                .fontWeight(.bold)
                            Text("A parabola is the set of all points equidistant from a fixed point (focus) and a fixed line (directrix).")
                                .font(.body)
                        }
                        .padding()
                        .background(.ultraThinMaterial)
                        .cornerRadius(20)
                        .shadow(radius: 10)
                        .padding()
                        
                        Spacer()
                    }
                }
                
                Spacer()
            }
            .padding()
        }
    }
}

