import SwiftUI

struct TriangleView: View {
    @State private var base: Double = 100
    @State private var height: Double = 80
    @State private var animateCards = false
    @State private var flipped = [false, false, false]
    
    var hypotenuse: Double {
        sqrt(pow(base, 2) + pow(height, 2))
    }
    
    var body: some View {
        ScrollView {
            VStack(spacing: 20) {
                
                // Triangle Display (Right-angled triangle)
                ZStack {
                    Path { path in
                        let start = CGPoint(x: 150, y: 250)
                        let right = CGPoint(x: 150 + base, y: 250)
                        let top = CGPoint(x: 150, y: 250 - height)
                        path.move(to: start)
                        path.addLines([right, top, start])
                    }
                    .stroke(Color.orange, lineWidth: 3)
                    
                    Text("Base: \(String(format: "%.1f", base)), Height: \(String(format: "%.1f", height))")
                        .font(.caption)
                        .foregroundColor(.gray)
                        .offset(y: 100)
                }
                .frame(height: 300)
                
                Divider()
                
                Text("Area = ½ × base × height = \(String(format: "%.2f", 0.5 * base * height)) sq units")
                    .font(.headline)
                    .multilineTextAlignment(.center)
                    .padding()
                
                // Inputs
                Group {
                    HStack {
                        Text("Base:")
                        TextField("Base", value: $base, format: .number)
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                            .keyboardType(.decimalPad)
                        Text("Height:")
                        TextField("Height", value: $height, format: .number)
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                            .keyboardType(.decimalPad)
                    }
                }
                .padding(.horizontal)
                
                Divider()
                
                // Flip Cards
                VStack(spacing: 20) {
                    ForEach(0..<3) { index in
                        let title = ["Area", "Hypotenuse", "Perimeter"][index]
                        let value: String = {
                            switch index {
                            case 0: return "\(String(format: "%.2f", 0.5 * base * height)) sq units"
                            case 1: return "\(String(format: "%.2f", hypotenuse)) units"
                            default: return "\(String(format: "%.2f", base + height + hypotenuse)) units"
                            }
                        }()
                        let formula = [
                            "Area = ½ × base × height",
                            "Hypotenuse = √(base² + height²)",
                            "Perimeter = base + height + hypotenuse"
                        ][index]
                        
                        ZStack {
                            RoundedRectangle(cornerRadius: 20)
                                .fill(Color.orange)
                                .frame(height: 100)
                                .shadow(radius: 10)
                            
                            if flipped[index] {
                                Text(formula)
                                    .scaleEffect(x: -1, y: 1)
                                    .font(.headline)
                                    .foregroundColor(.white)
                                    .padding()
                            } else {
                                VStack {
                                    Text(title)
                                        .font(.title)
                                        .foregroundColor(.white)
                                        .bold()
                                    Text(value)
                                        .font(.subheadline)
                                        .foregroundColor(.white.opacity(0.8))
                                }
                                .padding()
                            }
                        }
                        .padding(.horizontal)
                        .rotation3DEffect(
                            .degrees(flipped[index] ? 180 : 0),
                            axis: (x: 0, y: 1, z: 0)
                        )
                        .onTapGesture {
                            withAnimation(.easeInOut) {
                                flipped[index].toggle()
                            }
                        }
                        .offset(y: animateCards ? 0 : 100)
                        .opacity(animateCards ? 1 : 0)
                        .animation(.easeOut.delay(Double(index) * 0.2), value: animateCards)
                    }
                }
                .onAppear {
                    animateCards = true
                }
                
                Divider()
                
                ZStack {
                    Image("yourBackgroundImage")
                        .resizable()
                        .scaledToFill()
                        .ignoresSafeArea()
                    
                    VStack {
                        VStack(alignment: .leading, spacing: 10) {
                            Text("Interesting Facts")
                                .font(.title)
                                .frame(maxWidth: .infinity)
                                .fontWeight(.bold)
                            Text("A right triangle follows the Pythagorean theorem. The sum of the squares of the base and height equals the square of the hypotenuse.")
                                .font(.body)
                        }
                        .padding()
                        .background(.ultraThinMaterial)
                        .cornerRadius(20)
                        .shadow(radius: 10)
                        .padding()
                        
                        Spacer()
                    }
                }
                
                Spacer()
            }
            .padding()
        }
    }
}
